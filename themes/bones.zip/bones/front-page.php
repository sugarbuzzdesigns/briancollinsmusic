<?php get_header(); ?>

			<div id="content">
				<div class="bg-wrap wrap">
					<div id="bc-slideshow" class="cf no-mobile">
						<ul class="bxslider">				
							<li><a href="/shop"><img src="http://briancollinsmusic.com/wp-content/uploads/2014/12/BC_HEALING_HOLIDAYS_SALE_HERO.jpg"/></a></li>
							<li><a target="_blank" href="https://www.youtube.com/watch?v=llbn88Lun7o&feature=youtu.be&list=UUfQ_YbFpX9NQsBR5X_kK59Q"><img src="http://briancollinsmusic.com/wp-content/uploads/2014/12/BC_NRL_VIDEO.jpg" /></a></li>
							<!-- <li><img src="http://briancollinsmusic.com/wp-content/uploads/2014/10/BC_UK_HERO.jpg"/></li> -->
							<li><img src="http://briancollinsmusic.com/wp-content/uploads/2014/10/BC_HH_DL_HERO.jpg" /></li>
							<li><img src="http://briancollinsmusic.com/wp-content/uploads/2014/10/BC_ON_ZUUS_COUNTRY.jpg" /></li>
							<li><img src="<?php bloginfo('template_directory'); ?>/library/images/BC_THE_HIGHWAY_REQUEST.jpg" /></li>
							<li><img src="<?php bloginfo('template_directory'); ?>/library/images/BC_COUNTRY_RADIO_HERO.jpeg" /></li>
						</ul>
					</div>

					<div id="sponsor-box" class="cf no-mobile d-1of2">
						<div class="inner">
							<a href="http://www.bcbrigade.com" target="_blank"><input type="image" style="width:100%;" src="http://briancollinsmusic.com/wp-content/uploads/2014/12/brigade_notify.jpg" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!"></a>
							<!-- <a href=""><img src="http://briancollinsmusic.com/wp-content/uploads/2014/09/sponsor.jpg" alt=""></a> -->
<!-- 							<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
								<input type="hidden" name="cmd" value="_s-xclick">
								<input type="hidden" name="hosted_button_id" value="RBC629J5P9YSY">
								<input type="image" src="http://briancollinsmusic.com/wp-content/uploads/2014/09/sponsor.jpg" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
								<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
							</form> -->
						</div>
					</div>					

					<div id="video-feed" class="cf no-mobile d-1of2">
						<div id="video-wrap">
							<div id="video-strip">
								<div class="video">
									<iframe width="300" height="169" src="//www.youtube.com/embed/spyrU81JIA8?rel=0" frameborder="0" allowfullscreen></iframe>
								</div>							
								<div class="video">
									<iframe width="300" height="169" src="//www.youtube.com/embed/_fqrGx9EuwY?rel=0" frameborder="0" allowfullscreen></iframe>
								</div>							
								<div class="video">
									<iframe width="300" height="169" src="//www.youtube.com/embed/gscGxfldWnU?rel=0" frameborder="0" allowfullscreen></iframe>
								</div>
								<div class="video">
									<iframe width="300" height="169" src="//www.youtube.com/embed/UQQwDOe_zEw?rel=0" frameborder="0" allowfullscreen></iframe>
								</div>
								<div class="video">
									<iframe width="300" height="169" src="//www.youtube.com/embed/qQMDUvNrPrw?rel=0" frameborder="0" allowfullscreen></iframe>
								</div>
								<div class="video">
									<iframe width="300" height="169" src="//www.youtube.com/embed/P5maNxa6XDw?rel=0" frameborder="0" allowfullscreen></iframe>
								</div>
								<div class="video">
									<iframe width="300" height="169" src="//www.youtube.com/embed/FYQE_KOKH7Q?rel=0" frameborder="0" allowfullscreen></iframe>
								</div>
								<div class="video">
									<iframe width="300" height="169" src="//www.youtube.com/embed/t39VeTinccs?rel=0" frameborder="0" allowfullscreen></iframe>
								</div>																
							</div>		
						</div>									
					</div>				
		
					<div id="main-content" class="cf no-mobile t-all">
						<div id="left-col" class="d-1of2 t-1of2 front-page-col">
							<div id="latest-news" class="inner-content d-all">
								<h2 class="heading">Latest News</h2>
								<?php $args = array( 'post_type' => 'post', 'posts_per_page' => 8); ?>

								<?php $custom_query = new WP_Query($args); if (have_posts()) : while($custom_query->have_posts()) : $custom_query->the_post(); ?>
								<div class="news-story">
									<div class="news-thumb">
										<?php if(has_post_thumbnail()) { $image_src = wp_get_attachment_image_src( get_post_thumbnail_id(),'thumbname' ); echo '<img src="' . $image_src[0] . '" width="100%" />'; } ?>
									</div>
									<div class="news-content">
										<small><?php the_date(); ?></small>
										<h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
										<?php the_content(); ?>
									</div>
								</div>
								<?php endwhile; wp_reset_postdata(); endif; ?>		

								<a href="http://briancollinsmusic.com/news/" class="see-all-news">See All News</a>	

								<style>
									a.see-all-news {
										background: #323944;
										padding: 5px 10px;
										color: #fff;
										display: block;
										text-align: center;
										margin: 0 0 10px 0;
										text-decoration: none;
									}

									a.see-all-news:hover {
										background: #4C5563;
										color: #fff;
									}
								</style>																		
							</div>							
						</div>
						<div id="right-col" class="d-1of2 t-1of2 front-page-col">
							<div id="newsletter-signup" class="inner-content d-all">
								<h2 class="heading">Join the BC Mailing List</h2>
								<h4>Don't miss all of the awesome Brian Collins news and events. Sign up for the exclusive Brian Collins newsletter.</h4>

								<?php dynamic_sidebar( 'newsletter-widget' ); ?>
								<span style="display:none;"><?php dynamic_sidebar( 'newsletter-fb-test' ); ?></span>
							</div>
							<div id="store-feed" class="inner-content d-all">
								<h2 class="heading">From the BC Store</h2>
								<div id="store-wrap">
									<div id="store-film-strip">
										<div class="content">
											<?php
												$args = array(
													'post_type' => 'product',
													'posts_per_page' => 12
													);
												$loop = new WP_Query( $args );
												if ( $loop->have_posts() ) {
													while ( $loop->have_posts() ) : $loop->the_post();
														woocommerce_get_template_part( 'content', 'product' );
													endwhile;
												} else {
													echo __( 'No products found' );
												}
												wp_reset_postdata();
											?>									
										</div>
									</div>	
								</div>								
							</div>								
							<div class="inner-content d-all">
								<h2 class="heading">Social</h2>
								<div class="content">
									<a class="twitter-timeline" href="https://twitter.com/officialbcb" data-widget-id="501590129476001792">Tweets by @officialbcb</a>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
								</div>
							</div>							
						</div>
					</div>
				</div>
			</div>

<?php get_footer(); ?>
