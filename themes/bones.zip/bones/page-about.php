<?php
/*
 Template Name: Custom Page Example
 *
 * This is your custom page template. You can create as many of these as you need.
 * Simply name is "page-whatever.php" and in add the "Template Name" title at the
 * top, the same way it is here.
 *
 * When you create your page, you can just select the template and viola, you have
 * a custom page template to call your very own. Your mother would be so proud.
 *
 * For more info: http://codex.wordpress.org/Page_Templates
*/
?>

<?php get_header(); ?>

			<div id="content">

				<div id="inner-content" class="wrap cf">

						<div id="main" class="d-all cf" role="main">
							
							<div id="bc-slideshow" class="cf no-mobile">
								<div class="content">
									<svg version="1.1" id="LOGO" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
										 width="198px" height="277.75px" viewBox="0 0 198 277.75" enable-background="new 0 0 198 277.75" xml:space="preserve">
									<path fill-rule="evenodd" clip-rule="evenodd" fill="#231F20" d="M43.723,206.738c-3.21-1.955-6.592-4.496-10.177-4.53
										c2.172,1.918,4.899,3.408,7.53,5.394c1.038-0.161,2.062-0.379,3.077-0.63C44.009,206.894,43.858,206.819,43.723,206.738z"/>
									<path fill-rule="evenodd" clip-rule="evenodd" fill="#231F20" d="M31.45,205.007c-0.591,0.288-0.749-0.856-1.356-0.497
										c0.472,1.111,0.988,2.233,1.411,3.331c0.138,0.013,0.272,0.031,0.411,0.043c0.306,0.025,0.608,0.039,0.912,0.059
										C32.332,206.969,31.848,205.988,31.45,205.007z"/>
									<path fill-rule="evenodd" clip-rule="evenodd" fill="#231F20" d="M27.767,203.514c-0.759,1.087-0.861,2.346-1.339,3.509
										c0.373,0.088,0.749,0.169,1.127,0.245C27.708,206.036,27.785,204.787,27.767,203.514z"/>
									<path fill="#231F20" d="M95.059,125c-6.492-2.719-12.294-5.479-17.6-7.647c3.086,2.566,6.752,4.969,10.615,6.119
										C90.08,124.067,92.542,124.626,95.059,125z"/>
									<path fill="#231F20" d="M108.966,153.118c14.718,5.062,28.551,7.63,41.13,7.63c12.68,0,23.553-3.563,32.33-10.585
										c8.853-7.084,13.728-16.092,14.483-26.791c0.573-9.721-2.288-17.209-8.499-22.26c-5.505-4.365-12.841-6.577-21.803-6.577
										c-5.067,0-10.197,0.64-15.382,1.903c-0.756,3.434-1.922,6.88-3.527,10.254c-5.727,12.02-18.188,17.626-23.284,19.48
										c-6.072,2.202-15.413,3.625-23.796,3.625c-4.061,0-9.212-0.81-13.782-2.167c-7.646-2.276-14.397-8.58-18.258-12.811
										c-2.377,2.56-5.617,5.794-8.489,7.783c-3.994,2.763-12.365,7.723-23.55,9.893c-2.239,0.435-4.443,0.646-6.739,0.646
										c-3.844,0-7.201-0.603-10.227-1.203C9.467,140.264,3.49,150.847,1.817,163.426c-0.368,2.556-0.562,5.074-0.562,7.499
										c0,10.39,2.809,19.038,8.339,25.703c5.585,6.717,13.102,10.503,22.322,11.256c1.192,0.101,2.366,0.153,3.525,0.153
										c7.439,0,14.385-2.174,20.701-6.476l-0.256,1.274c-0.726,4.722-1.098,9.313-1.098,13.634c0,11.023,1.918,20.751,5.736,29.14
										c2.644,5.81,6.195,10.965,10.652,15.477c3.886,3.939,8.407,8.436,13.855,10.803c5.443,2.363,15.111,4.419,18.436,4.836
										c2.95,0.371,7.604,0.709,10.503,0.709c0.369,0,0.709-0.005,1.014-0.017c2.703-0.101,7.225-0.174,9.912-0.457
										c3.225-0.347,7.392-1.109,9.68-1.73c2.29-0.626,9.023-2.56,13.504-5.019c2.781-1.53,5.751-3.315,8.832-5.303
										c1.922-1.26,4.601-3.246,6.363-4.589c13.173-10.097,21.24-22.731,24.795-37.273c1.096-4.914,1.651-9.632,1.651-14.029
										c0-11.394-3.638-20.428-10.812-26.847c-7.108-6.363-16.348-9.591-27.49-9.591c-11.446,0-21.57,3.562-30.081,10.595
										c-7.307,6-11.499,12.631-12.451,19.666c-1.174,7.771,1.534,14.995,8.045,21.489l6.242,6.22l-2.815-8.353
										c-0.449-1.356-0.683-2.645-0.683-3.859c0-3.952,1.637-7.064,5.053-9.551c2.857-2.213,5.666-3.295,8.574-3.295
										c2.953,0,5.402,1.164,7.499,3.548c2.068,2.38,2.797,6.033,2.172,10.901c-1.46,11.508-10.111,17.098-26.453,17.098
										c-7.83,0-13.958-2.407-18.767-7.389c-5.247-5.245-7.914-12.816-7.914-22.501c0-2.884,0.256-5.904,0.767-9.017
										C93.3,180.158,99.476,165.022,108.966,153.118z M140.794,126.486c6.138-2.639,8.631-3.031,9.569-3.031
										c3.751,0,6.394,0.745,7.638,2.152c0.872,0.981,1.178,2.393,0.945,4.316c-0.274,2.24-1.112,9.09-15.78,9.09
										c-5.82,0-12.016-1.067-18.466-3.174C129.727,131.948,135.117,128.815,140.794,126.486z M70.192,165.018
										c-1.564-3.398-4.035-6.372-7.418-8.905c-2.066-1.305-4.348-2.437-6.756-3.376l-5.875-2.276l3.368,5.324
										c3.099,4.892,4.521,8.741,4.231,11.399c-0.749,5.577-3.648,8.056-9.394,8.056c-3.674,0-6.43-1.11-8.435-3.41
										c-1.987-2.298-2.653-5.365-2.025-9.43c0.632-4.993,3.094-9.177,7.496-12.772c5.101-4.108,12.104-6.194,20.815-6.194
										c4.932,0,11.088,0.802,18.319,2.383C78.705,152.8,73.902,159.234,70.192,165.018z"/>
									<path fill="#231F20" d="M143.782,104.825c4.807-10.101,6.054-22.354,0.423-32.217c-5.622-9.85-12.285-12.557-16.219-14.526
										c-2.859-1.438-4.257-1.891-13.365-3.511c0,0,2.896-0.071,7.894-1.945c4.1-1.538,7.992-3.687,10.531-5.465
										c1.982-1.385,5.851-4.332,8.102-8.1c3.317-5.543,3.708-12.035,2.027-18.419c-2.817-10.702-9.736-15.534-14.355-17.111
										c-4.402-1.502-5.305-2.04-10.093-2.572c-1.23-0.138-2.589-0.206-4.061-0.206c-2.917,0-6.283,0.269-10.002,0.798
										c-6.151,0.879-12.855,3.063-17.427,5.348c-3.256,1.628-9.503,4.754-9.503,4.754s-0.616-0.907-2.429-2.467
										c-1.966-1.693-4.266-2.792-7.079-4.267c-2.815-1.475-5.886-2.509-12.28-2.77c-0.418-0.018-0.865-0.027-1.334-0.027
										c-5.533,0-14.369,1.292-21.239,4.973C30.19,8.8,25.372,12.434,21.89,15.61c-3.596,3.28-7.318,9.398-9.11,13.069
										c-2.72,5.617-3.222,14.655-2.377,21.979c0.85,7.322,7.097,15.095,11.887,18.752c4.333,3.317,11.882,6.013,17.675,6.013
										c0.614,0,1.199-0.031,1.756-0.093c7.741-0.841,10.755-2.435,13.657-3.796c4.505-2.112,9.438-8.452,9.438-8.452
										s-2.332,7.183-4.371,13.101c-2.817,8.16-4.978,11.146-9.718,16.048c-7.887,8.163-12.116,8.725-16.331,9.845
										c-1.516,0.402-3.416,0.735-5.266,0.735c-3.329,0-6.549-1.058-7.266-4.676c-0.968-4.819,2.859-9.488,7.636-10.324
										c0.667-0.121,1.338-0.169,2-0.169c4.918,0,9.408,2.85,9.408,2.85s-5.117-9.239-15.818-9.24c-0.25,0-0.502,0.005-0.759,0.015
										c-8.818,0.349-13.417,2.467-17.703,7.206c-4.304,4.768-6.067,12.234-5.706,16.203c0.534,5.893,1.763,11.777,6.626,16.2
										c4.049,3.683,8.46,5.922,11.965,6.625c3.095,0.621,6.465,1.3,10.287,1.3c1.857,0,3.821-0.161,5.912-0.566
										c9.746-1.891,17.345-6.044,21.909-9.202c4.786-3.314,11.044-10.861,11.044-10.861s8.994,12.198,19.409,15.298
										c3.502,1.04,8.389,1.986,12.544,1.986c8.193,0,16.89-1.397,22.318-3.365C129.881,119.566,139.383,114.059,143.782,104.825z
										 M68.509,37.679c0,0-2.859-5.736-6.832-7.639c-2.858-1.368-4.136-1.476-6.638-1.476c-0.464,0-0.97,0.004-1.536,0.004
										c-1.265,0-3.539,0.405-4.822,0.802c-6.074,1.915-7.229,6.255-7.229,6.255s3.663-1.661,7.787-1.661c1.242,0,2.521,0.15,3.756,0.542
										c3.651,1.149,4.089,4.087,4.368,6.333c0.274,2.255-1.557,6.053-3.804,8.306c-2.155,2.152-3.948,3.378-8.877,4.222
										c-0.945,0.167-1.904,0.239-2.85,0.239c-3.882,0-7.61-1.303-10.102-3.338c-3.094-2.538-5.466-6.31-3.646-15.251
										c1.906-9.363,9.423-13.354,12.807-15.161c2.896-1.54,7.211-2.631,11.41-3.08c0.775-0.082,1.471-0.132,2.177-0.132
										c1.197,0,2.423,0.146,4.118,0.534c2.697,0.622,6.697,1.476,9.243,7.504C70.165,30.192,68.509,37.679,68.509,37.679z M89.607,28.484
										c0.548-0.694,2.263-2.121,3.06-2.694c2.75-1.962,5.617-3.359,9.348-4.374c2.342-0.647,4.651-0.944,6.799-0.944
										c5.69,0,10.228,2.123,11.262,5.754c1.423,4.995-4.354,10.941-12.91,13.278c-3.363,0.916-5.694,1.406-8.683,1.406
										c-0.82,0-1.697-0.035-2.658-0.113c-2.633-0.21-3.4-1.043-4.421-1.763c-1.32-0.919-1.824-2.325-2.217-3.723
										C88.58,33.183,87.95,30.594,89.607,28.484z M118.736,86.614c-1.135,3.912-3.131,6.418-6.341,8.454
										c-2.786,1.75-6.069,2.676-9.49,2.676c-1.331,0-2.692-0.145-4.046-0.428c-4.817-1.02-7.409-2.195-10.558-5.119
										c-3.64-3.381-4.124-8.038-4.124-8.038s0.016-0.875,1.16-6.215c1.146-5.341,2.064-9.211,2.644-12.792
										c0.162-0.992,0.151-1.115,0.137-1.115c-0.009,0-0.014,0.007-0.014,0.007c-0.007,0,0.018-0.076,0.142-0.538
										c0.128-0.474,1.219-0.73,2.945-0.73c2.868,0,7.476,0.704,12.267,2.205c6.42,2.012,9.708,5.382,11.891,8.046
										C118.816,77.222,119.743,83.146,118.736,86.614z"/>
									<rect x="609.75" y="286.751" fill="none" width="841.89" height="595.28"/>
									</svg>
								</div>
								<img class="no-mobile" src="<?php bloginfo('template_directory'); ?>/library/images/BC_WEB_HERO_1140x400.jpg" />
							</div>			

							<div id="about-bc" class="d-all interior-wrap">
								<h2 class="heading">About Brian Collins</h2>
								
								<div class="content">
									<p>Hailing from the music hotbed of West Georgia, Brian Collins radiates a true southern soul. Humbled by his modest
									upbringing as the son of two truck-driving parents, Brian exudes passion and love in every corner of his career. The highly 
									anticipated release of his album, “Healing Highway” is set for October with the lead-off single “Never Really Left” hitting 
									radio airwaves in August. </p>

									<p>Over the course of his career, Brian has worn many hats in the industry. Not only is he a top notch singer/songwriter and 
									artist, but Brian has also been praised for his talents as a producer, engineer and graphic designer. Brian co-wrote every 
									song on the new album and produced it alongside Mills Logan and Kenny Greenberg. 
									“I am very proud of this project,” said Brian. “We worked hard to write, record and produce material that captivates me as 
									an artist and person... I think we nailed it.”</p>

									<p>Inspiration for Brian’s songwriting comes from many different aspects of his life. In 1985, Brian’s younger sister, Karen 
									Collins, passed away from Leukemia. Brian used his creative and artistic ability to heal the wounds of his family’s tragedy 
									through a song he co-wrote with close friend and Zac Brown Band bass player, John Driskell Hopkins, titled “She Will 
									Ride.” In January of 2013, Karen’s memory became an anthem to find a cure for cancer through the launch of the She Will 
									Ride Foundation. The non-profit, founded by Brian and Blue Light Entertainment, aims at contributing financially to the 
									determination of finding a cure for cancer and leukemia in this generation.</p>

									<p>Take a cross between Eli Young Band, Bob Seger, Bruce Springsteen, and Marc Broussard—and you have a sound 
									unlike any other—you have something unique. And uniqueness describes Brian in every sense of the word. His honest 
									lyrics capture the heart of every listener while the soulful quality of his voice gives meaningful expression to songs that 
									bend the lines between Country and soul.</p>

									<p>Brian’s hard working nature and undeniable talent has led him to share the stage with KISS, Will Hoge, Sister Hazel, 
									James Otto, Colin Hay (of Men At Work), Zac Brown Band, the Smithereens, Marshall Tucker Band, Georgia Satellites, 
									Edwin McCain, Blackberry Smoke, Alabama, Lynyrd Skynyrd and more. The depth of his songwriting and the magnitude 
									of his perspective attest to Brian’s broad appeal and ever-growing fan base, which has led him to play over 150 dates a 
									year.</p> 

									<p>A Brian Collins show offers a well-rounded, dynamic live performance that engulfs the senses and takes audiences on a 
									notable journey. Most recently he had the privilege of playing on the Alabama & Friends Cruise and is on the bill for The 
									Rock Boat 2015 cruise with Sister Hazel, The Bare Naked Ladies and Michael Franti & the Spearhead. 
									In 2005, Brian launched "Blue Light Studio” Not only did Brian make his vision of the company into a reality, but he also 
									personally designed all of the recording rooms where he produced/engineered albums and tracks for hard rockers Skid 
									Row, Tony Lucca, The Luchagores, Atlanta based rap artists T.I., Twista and Frank White, as well as acoustic rockers 
									Nic Cowan and Tim O’Donovan. In 2013 Brian partnered with manager and music business developer Santos Vasquez 
									and Belmont graduate Tommy Smith and formed the LLC "Blue Light Entertainment” a booking and publishing company. 
									Since the launch, they have seen National fan recognition through touring and organized the BC Brigade (Brian’s Fan Club).</p>
								</div>
							</div>			

							<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

							<?php the_content(); ?>

							<?php endwhile; endif;?>

						</div>

						<!-- <?php get_sidebar(); ?> -->

				</div>

			</div>


<?php get_footer(); ?>
