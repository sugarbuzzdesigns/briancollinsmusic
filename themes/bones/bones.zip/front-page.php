<?php get_header(); ?>

			<div id="content">
				<div class="bg-wrap wrap">
					<div id="bc-slideshow" class="cf">
						<img src="<?php bloginfo('template_directory'); ?>/library/images/BC_WEB_HERO_1140x400.jpg" />
					</div>

					<div id="video-feed" class="cf">
						<div id="video-strip">
							<div class="video">
								<iframe width="300" height="169" src="//www.youtube.com/embed/HViKpM7E7as" frameborder="0" allowfullscreen></iframe>
							</div>
							<div class="video">
								<iframe width="300" height="169" src="//www.youtube.com/embed/xTcGem6LD2I?rel=0" frameborder="0" allowfullscreen></iframe>
							</div>
							<div class="video">
								<iframe width="300" height="169" src="//www.youtube.com/embed/xTcGem6LD2I?rel=0" frameborder="0" allowfullscreen></iframe>
							</div>
							<div class="video">
								<iframe width="300" height="169" src="//www.youtube.com/embed/xTcGem6LD2I?rel=0" frameborder="0" allowfullscreen></iframe>
							</div>
							<div class="video">
								<iframe width="300" height="169" src="//www.youtube.com/embed/xTcGem6LD2I?rel=0" frameborder="0" allowfullscreen></iframe>
							</div>
						</div>											
					</div>				
		
					<div id="main-content" class="cf">
						<div id="left-col" class="d-1of2 front-page-col">
							<div id="latest-news" class="inner-content d-all">
								<h2>Latest News</h2>
								<div class="news-story">
									<div class="news-thumb">
										<img src="http://placehold.it/140x100">
									</div>
									<div class="news-content">
										<small>4/24/2014</small>
										<h4>Here is a title</h4>
										<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Officia totam aliquam, doloribus? Ex praesentium tempora ut libero beatae delectus harum perspiciatis...<a href="#">Read More</a></p>
									</div>
								</div>
								<div class="news-story">
									<div class="news-thumb">
										<img src="http://placehold.it/140x100">
									</div>
									<div class="news-content">
										<small>4/24/2014</small>
										<h4>Here is a title</h4>
										<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Officia totam aliquam, doloribus? Ex praesentium tempora ut libero beatae delectus harum perspiciatis...<a href="#">Read More</a></p>
									</div>
								</div>
								<div class="news-story">
									<div class="news-thumb">
										<img src="http://placehold.it/140x100">
									</div>
									<div class="news-content">
										<small>4/24/2014</small>
										<h4>Here is a title</h4>
										<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Officia totam aliquam, doloribus? Ex praesentium tempora ut libero beatae delectus harum perspiciatis...<a href="#">Read More</a></p>
									</div>
								</div>	
								<div class="news-story">
									<div class="news-thumb">
										<img src="http://placehold.it/140x100">
									</div>
									<div class="news-content">
										<small>4/24/2014</small>
										<h4>Here is a title</h4>
										<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Officia totam aliquam, doloribus? Ex praesentium tempora ut libero beatae delectus harum perspiciatis...<a href="#">Read More</a></p>
									</div>
								</div>
								<div class="news-story">
									<div class="news-thumb">
										<img src="http://placehold.it/140x100">
									</div>
									<div class="news-content">
										<small>4/24/2014</small>
										<h4>Here is a title</h4>
										<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Officia totam aliquam, doloribus? Ex praesentium tempora ut libero beatae delectus harum perspiciatis...<a href="#">Read More</a></p>
									</div>
								</div>
								<div class="news-story">
									<div class="news-thumb">
										<img src="http://placehold.it/140x100">
									</div>
									<div class="news-content">
										<small>4/24/2014</small>
										<h4>Here is a title</h4>
										<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Officia totam aliquam, doloribus? Ex praesentium tempora ut libero beatae delectus harum perspiciatis...<a href="#">Read More</a></p>
									</div>
								</div>																								
							</div>							
						</div>
						<div id="right-col" class="d-1of2 front-page-col">
							<div id="newsletter-signup" class="inner-content d-all">
								<h2>Join the BC Mailing List</h2>
								<h4>Don't miss all of the awesome Brian Collins news and events. Sign up for the exclusive Brian Collins newsletter.</h4>
								<form action="#">
									<input type="text" placeholder="Enter your email"/>
									<input type="submit" value="Sign Me up"/>
								</form>
							</div>
							<div id="store-feed" class="inner-content d-all">
								<h2>From the BC Store</h2>
								<div id="store-film-strip">
									<div class="content">
										<div class="store-item">
											<img src="<?php bloginfo('template_directory'); ?>/library/images/store/bc-t-shirt-blue.jpg" />
											<p class="store-item-desc">BC T-Shirt</p>
										</div>
										<div class="store-item">
											<img src="<?php bloginfo('template_directory'); ?>/library/images/store/bc-t-shirt-grey.jpg" />
											<p class="store-item-desc">BC T-Shirt</p>
										</div>	
										<div class="store-item">
											<img src="<?php bloginfo('template_directory'); ?>/library/images/store/bc-t-shirt-blue.jpg" />
											<p class="store-item-desc">BC T-Shirt</p>
										</div>
										<div class="store-item">
											<img src="<?php bloginfo('template_directory'); ?>/library/images/store/bc-t-shirt-grey.jpg" />
											<p class="store-item-desc">BC T-Shirt</p>
										</div>	
									</div>
								</div>									
							</div>								
							<div class="inner-content d-all">
								<h2>Social</h2>
								<div class="content">
									<a class="twitter-timeline" href="https://twitter.com/SgrbzzDesigns" data-widget-id="459745251591090176">Tweets by @SgrbzzDesigns</a>
									<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
								</div>
							</div>							
						</div>
					</div>
				</div>
			</div>

<?php get_footer(); ?>
